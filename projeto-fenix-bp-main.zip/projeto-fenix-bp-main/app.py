import streamlit as st
from bp.ui.streamlit_dashboard import render_dashboard


def main():
    render_dashboard()


if __name__ == "__main__":
    main()
